# set09103_advanced_web_tech
set09103 Advanced Web Tech code


static dir
    - stores static files such as images (incl. icons), fonts, css and javascript as well as the favicon

templates dir
    - stores html template files